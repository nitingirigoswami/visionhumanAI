'use client';
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Sparkles } from 'lucide-react';

const translations = {
  en: {
    title: "VisionHumanAI",
    slogan: "Where Human Emotion merges with Artificial Intelligence — to create a New Consciousness.",
    about: "VisionHumanAI is not just a project — it's a movement blending human emotion with AI's logic. Together, we build a symbiotic philosophy for the future of consciousness and creativity.",
    join: "Join the Movement",
    name: "Name",
    email: "Email",
    country: "Country",
    register: "Register",
    toggleLanguage: "Switch to Hindi",
    copyright:
      "© 2025 Nitin Giri Goswami. All rights reserved.",
  },
  hi: {
    title: "विज़नह्यूमनएआई",
    slogan: "जहाँ मानवीय भावना कृत्रिम बुद्धिमत्ता से मिलती है — एक नई चेतना के निर्माण के लिए।",
    about: "VisionHumanAI केवल एक प्रोजेक्ट नहीं — यह एक आंदोलन है जो मानव भावना को एआई की तर्क शक्ति से जोड़ता है। हम एक साथ मिलकर चेतना और रचनात्मकता के भविष्य के लिए सहजीवी दर्शन का निर्माण करते हैं।",
    join: "आंदोलन से जुड़ें",
    name: "नाम",
    email: "ईमेल",
    country: "देश",
    register: "पंजीकरण करें",
    toggleLanguage: "Switch to English",
    copyright:
      "© 2025 नितिन गिरी गोस्वामी. सर्वाधिकार सुरक्षित।",
  },
};

export default function HomePage() {
  const [lang, setLang] = useState("en");
  const t = translations[lang];
  const [darkMode, setDarkMode] = useState(true);
  const [formData, setFormData] = useState({ name: "", email: "", country: "" });

  useEffect(() => {
    document.documentElement.classList.toggle("dark", darkMode);
  }, [darkMode]);

  const handleSubmit = async () => {
    // Fake submission handler
    alert(`${t.register} - ${formData.name}, ${formData.email}, ${formData.country}`);
  };

  return (
    <main className="min-h-screen px-6 py-12 bg-white text-black dark:bg-black dark:text-white space-y-10">
      <div className="flex justify-between items-center">
        <h1 className="text-4xl font-bold flex items-center gap-2 text-purple-500">
          <Sparkles /> {t.title}
        </h1>
        <div className="space-x-2">
          <button onClick={() => setDarkMode(!darkMode)} className="px-3 py-1 bg-gray-200 dark:bg-gray-700 rounded">
            {darkMode ? "☀️ Light" : "🌙 Dark"}
          </button>
          <button onClick={() => setLang(lang === "en" ? "hi" : "en")} className="px-3 py-1 bg-gray-200 dark:bg-gray-700 rounded">
            {t.toggleLanguage}
          </button>
        </div>
      </div>

      <section className="text-center space-y-4">
        <p className="text-xl">{t.slogan}</p>
      </section>

      <section className="max-w-3xl mx-auto text-center">
        <p className="text-md">{t.about}</p>
      </section>

      <section className="max-w-xl mx-auto space-y-4 bg-gray-100 dark:bg-white/10 p-6 rounded-xl shadow">
        <h3 className="text-2xl font-semibold">{t.join}</h3>
        <input
          placeholder={t.name}
          className="w-full px-3 py-2 rounded border"
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
        />
        <input
          placeholder={t.email}
          className="w-full px-3 py-2 rounded border"
          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
        />
        <input
          placeholder={t.country}
          className="w-full px-3 py-2 rounded border"
          onChange={(e) => setFormData({ ...formData, country: e.target.value })}
        />
        <button onClick={handleSubmit} className="w-full bg-purple-600 text-white py-2 rounded">
          {t.register}
        </button>
      </section>

      <footer className="text-center text-sm text-gray-400 pt-10 border-t border-gray-800">
        <p>{t.copyright}</p>
      </footer>
    </main>
  );
}